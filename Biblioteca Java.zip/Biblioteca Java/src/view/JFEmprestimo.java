package view;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import utils.BdCliente;
import utils.BdEmprestimo;
import utils.BdLivro;
import model.Cliente;
import model.Emprestimo;
import model.Livro;

public class JFEmprestimo extends javax.swing.JFrame {  
   
    JFMulta enviaValor;
    private JFPrincipal telaPrincipal;
    boolean verifica = false;
    
    public JFEmprestimo() {
        initComponents();
        verifica = true;
        desabilitaCamposEmprestimo();        
        dataEmprestimo();      
        mostraDataDevolucao();
    }
    
    JFEmprestimo(JFPrincipal telaPrincipal) {
        
        this();
        this.telaPrincipal = telaPrincipal;
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bGPesquisa = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jT0IdEmprestimo = new javax.swing.JTextField();
        jT1IdCliente = new javax.swing.JTextField();
        jT2IdLivro = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jT4DataDevolucao = new javax.swing.JTextField();
        jT3DataEmprestimo = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jTPesquisar = new javax.swing.JTextField();
        jBPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEmprestimo = new javax.swing.JTable();
        jRClientes = new javax.swing.JRadioButton();
        jRLivros = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableLivro = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableCliente = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jBExcluir = new javax.swing.JButton();
        jBNovo = new javax.swing.JButton();
        jBSair = new javax.swing.JButton();
        jBCadastrar = new javax.swing.JButton();
        jBDevolver = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Empréstimos");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados Empréstimos"));

        jLabel1.setText("ID: ");

        jLabel2.setText("ID do cliente: ");

        jLabel3.setText("ID do livro: ");

        jLabel4.setText("Data do emprestimo:(d/m/a)");

        jLabel5.setText("Data de Devolução: (d/m/a)");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jT3DataEmprestimo)
                        .addComponent(jT4DataDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jT1IdCliente, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jT2IdLivro, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jT0IdEmprestimo, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jT0IdEmprestimo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jT1IdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jT2IdLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jT3DataEmprestimo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jT4DataDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jT0IdEmprestimo, jT1IdCliente, jT2IdLivro, jT3DataEmprestimo, jT4DataDevolucao});

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar Empréstimos"));

        jBPesquisar.setText("Pesquisar");
        jBPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPesquisarActionPerformed(evt);
            }
        });

        jTableEmprestimo.setModel(tmEmprestimo);
        jTableEmprestimo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableEmprestimoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableEmprestimo);

        bGPesquisa.add(jRClientes);
        jRClientes.setText("Clientes");

        bGPesquisa.add(jRLivros);
        jRLivros.setText("Livros");

        jLabel6.setText("Pesquisar por: ");

        jTableLivro.setModel(tmLivro);
        jTableLivro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableLivroMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableLivro);

        jTableCliente.setModel(tmCliente);
        jTableCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableClienteMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTableCliente);

        jLabel8.setText("Selecione o cliente abaixo: ");

        jLabel9.setText("Selecione o livro abaixo: ");

        jLabel11.setText("Empréstimos: ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(jRClientes)
                                .addGap(18, 18, 18)
                                .addComponent(jRLivros)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jTPesquisar))
                        .addGap(18, 18, 18)
                        .addComponent(jBPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(0, 124, Short.MAX_VALUE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRClientes)
                    .addComponent(jRLivros)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jBExcluir.setText("Excluir");
        jBExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBExcluirActionPerformed(evt);
            }
        });

        jBNovo.setText("Novo");
        jBNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBNovoActionPerformed(evt);
            }
        });

        jBSair.setText("Sair");
        jBSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSairActionPerformed(evt);
            }
        });

        jBCadastrar.setText("Emprestar");
        jBCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCadastrarActionPerformed(evt);
            }
        });

        jBDevolver.setText("Devolver");
        jBDevolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBDevolverMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jBExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBDevolver, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jBNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBSair, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(3, 3, 3))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jBCadastrar, jBDevolver, jBExcluir, jBNovo, jBSair});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBDevolver))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBSair)
                    .addComponent(jBCadastrar)
                    .addComponent(jBNovo))
                .addContainerGap())
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jBCadastrar, jBDevolver, jBExcluir, jBNovo, jBSair});

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setText("ATENÇÃO! Preencha os campos \"cliente\" e \"livro\" clicando");

        jLabel10.setText("no registro,encontrado na área de pesquisa.");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel10)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel10)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel1.getAccessibleContext().setAccessibleName("Cadastro de Clientes");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void jBNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBNovoActionPerformed
        limpaCamposEmprestimo();   
        limpaTabelaEmprestimo();
        limpaTabelaCliente();
        limpaTabelaLivro();
    }//GEN-LAST:event_jBNovoActionPerformed
      
    private void jBCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCadastrarActionPerformed
        try {  
            cadastraRegistro();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao efetuar empréstimo.");
        }
    }//GEN-LAST:event_jBCadastrarActionPerformed
     
    private void jBPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBPesquisarActionPerformed

        if (!(jRClientes.isSelected() || jRLivros.isSelected())) {            
            JOptionPane.showMessageDialog(rootPane, "Selecione um campo de pesquisa.");            
        } else if (jRClientes.isSelected()) {  

            try {
                listaContatosCliente();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Erro ao efetuar empréstimo.");
            }            
        } else if (jRLivros.isSelected()) {
            try {
                listaContatosLivro();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Problemas ao listar contatos.");
            }
        }
        
    }//GEN-LAST:event_jBPesquisarActionPerformed
    
    private void jTableEmprestimoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableEmprestimoMouseClicked
     
    }//GEN-LAST:event_jTableEmprestimoMouseClicked
    
    private void jBExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBExcluirActionPerformed
        try {
            excluirRegistro();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao excluir registro.");
        }
    }//GEN-LAST:event_jBExcluirActionPerformed
    
    private void jTableLivroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableLivroMouseClicked

        int linhaSelecionada = jTableLivro.getSelectedRow();
        
        jT2IdLivro.setText(jTableLivro.getValueAt(linhaSelecionada, 0).toString());
    }//GEN-LAST:event_jTableLivroMouseClicked


    private void jTableClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableClienteMouseClicked

        int linhaSelecionada = jTableCliente.getSelectedRow();
        jT1IdCliente.setText(jTableCliente.getValueAt(linhaSelecionada, 0).toString()); 
        try {
            listaContatosEmprestimo();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao listar emprestimos.");
        }
    }//GEN-LAST:event_jTableClienteMouseClicked
    
    private void jBDevolverMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBDevolverMouseClicked
        try {
            devolveLivro();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao devolver livro.");
        } catch (ParseException ex) {
            Logger.getLogger(JFEmprestimo.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }//GEN-LAST:event_jBDevolverMouseClicked
   
    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed

        telaPrincipal.setEnabled(true);
        
    }//GEN-LAST:event_formWindowClosed

    private void jBSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_jBSairActionPerformed
    
    
 
    private void cadastraRegistro() throws SQLException {
        if (!(jTableEmprestimo.getSelectedRow() != -1)) {
            if (verificaDados()) {
                if (verificaDisponibilidadeLivro()) {
                    BdEmprestimo d = new BdEmprestimo();
                    if (!d.verificaMultaCliente(pegaIdCliente())) {
                        try {
                            Emprestimo e = new Emprestimo();

                            e.setId_cliente(Integer.valueOf(jT1IdCliente.getText()));
                            e.setId_livro(Integer.valueOf(jT2IdLivro.getText()));
                            e.setData_emprestimo(salvaDataEmprestimo());
                            e.setData_devolucao(salvaDataDevolucao());

                            d = new BdEmprestimo();

                            d.adicionaEmprestimo(e);

                            alteraDisponibilidade("0");

                            JOptionPane.showMessageDialog(rootPane, "Empréstimo efetuado com sucesso.");
                            limpaCamposEmprestimo();

                            listaContatosEmprestimo();
                            listaContatosLivro();

                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(rootPane, "Erro ao efetuar empréstimo.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "ERRO Empréstimo não autorizado.\nUsuário com pendências correspondentes à multa.\n\n"
                                + "Só poderá solicitar um novo empréstimo após sanar as pendências.");
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Para cadastrar selecione apenas os campos 'Cliente' e 'Livro.',\n\n"
                    + "Para fazer um novo empréstimo clique em 'Novo'.");
        }
    }
    
    private boolean verificaDados() {
        if ((!jT1IdCliente.getText().equals("")) && (!jT2IdLivro.getText().equals("")) 
                && (!jT3DataEmprestimo.getText().equals(""))) {
            return true;
        }
        JOptionPane.showMessageDialog(rootPane, "Dados imcompletos.");
        return false;
    }
    
    public String disponibilidadeLivro() {
        int linhaSelecionada = jTableLivro.getSelectedRow();        
        String status = (String) jTableLivro.getValueAt(linhaSelecionada, 3);  
        return status;
    }
    
    private boolean verificaDisponibilidadeLivro() {
        if (! disponibilidadeLivro().equals("0")) {
            return true;
        }
        JOptionPane.showMessageDialog(rootPane, "Livro selecionado está indisponível.");
        return false;
    }
    
    
    private void dataEmprestimo() {
        Date data = new Date();  
        
        SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy");  
        String s = formataData.format( data ); 
        
        jT3DataEmprestimo.setText(formataData.format(data));      
    }   
    
    private String salvaDataEmprestimo() {
        Date data = new Date();  
        
        SimpleDateFormat formataData = new SimpleDateFormat("yyyy-MM-dd");  
        String dataEmprestimoFormatada = formataData.format(data); 
        
        return dataEmprestimoFormatada;   
    }  
    
    private void mostraDataDevolucao() {        
        Date dataDevolucao = new Date();
        dataDevolucao.setDate(dataDevolucao.getDate() + 7);
        SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy");        
        String dataDevolucaoFormatada = formataData.format(dataDevolucao);
        jT4DataDevolucao.setText(dataDevolucaoFormatada);
    }    
    
    public String salvaDataDevolucao() {
        Date dataDevolucao = new Date();
        dataDevolucao.setDate(dataDevolucao.getDate() + 7);
        SimpleDateFormat formataData = new SimpleDateFormat("yyyy-MM-dd");        
        String dataDevolucaoFormatada = formataData.format(dataDevolucao);
        return dataDevolucaoFormatada;
    }
    
    public String pegaDataDevolucaoTabela() throws ParseException {
        
        int linhaSelecionada = jTableEmprestimo.getSelectedRow();   
        String dataTabela = (jTableEmprestimo.getValueAt(linhaSelecionada, 4)).toString();
        
        SimpleDateFormat formataData = new SimpleDateFormat ("yyyy-MM-dd"); 
        Date dataDevolucao = new Date();
        
        dataDevolucao = formataData.parse(dataTabela); 
        
        return formataData.format(dataDevolucao);
    }
    
    private long diferencaData() throws ParseException {
        LocalDate atual = LocalDate.now();
        LocalDate dataDevolucao = LocalDate.parse(pegaDataDevolucaoTabela());
        long diferenca = 0;
        if (dataDevolucao.compareTo(atual) < 0) {
            diferenca = ChronoUnit.DAYS.between(dataDevolucao, atual);
        }
        return diferenca;       
    }
    
    DefaultTableModel tmCliente = new DefaultTableModel(null, new String[]{"Id", "Nome", "CPF"});    
    List<Cliente> clientes;  
    private void listaContatosCliente() throws SQLException {        
        BdCliente d = new BdCliente();
        clientes = d.getLista("%" + jTPesquisar.getText() + "%"); 
        mostraPesquisaCliente(clientes);
        clientes.clear();
    }
    
    private void mostraPesquisaCliente(List<Cliente> clientes) {
        limpaTabelaCliente();
        
        if (clientes.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Nenhum registro não encontrado.");
        } else {             
            String[] linha = new String[] {null, null, null};
            for (int i = 0; i < clientes.size(); i++) {
                tmCliente.addRow(linha);
                tmCliente.setValueAt(clientes.get(i).getId(), i, 0);
                tmCliente.setValueAt(clientes.get(i).getNome(), i, 1);
                tmCliente.setValueAt(clientes.get(i).getCpf(), i, 2);              
            }            
        }
    }   
    
    private void limpaTabelaCliente() {       
        while (tmCliente.getRowCount() > 0) {            
            tmCliente.removeRow(0);
        }
    } 
    
    DefaultTableModel tmEmprestimo = new DefaultTableModel(null, new String[]{"ID", "ID Cliente", "ID Livro", "Data Emprestimo", "Data Devolução"});
    List<Emprestimo> emprestimos;
    
    private void listaContatosEmprestimo() throws SQLException { 
        BdEmprestimo d = new BdEmprestimo();
        emprestimos = d.getListaPorCliente(pegaIdCliente()); 
        mostraPesquisaEmprestimo(emprestimos);
        emprestimos.clear();
    }
    
    private void mostraPesquisaEmprestimo(List<Emprestimo> emprestimos) {
        limpaTabelaEmprestimo();
        
        if (emprestimos.isEmpty()) {
        } else {            
            String[] linha = new String[] {null, null, null, null, null};
            for (int i = 0; i < emprestimos.size(); i++) {
                tmEmprestimo.addRow(linha);
                tmEmprestimo.setValueAt(emprestimos.get(i).getId_emprestimo(), i, 0);
                tmEmprestimo.setValueAt(emprestimos.get(i).getId_cliente(), i, 1);
                tmEmprestimo.setValueAt(emprestimos.get(i).getId_livro(), i, 2);
                tmEmprestimo.setValueAt(emprestimos.get(i).getData_emprestimo(), i, 3);
                tmEmprestimo.setValueAt(emprestimos.get(i).getData_devolucao(), i, 4);              
            }            
        }
    } 
    
    private void limpaTabelaEmprestimo() {       
        while (tmEmprestimo.getRowCount() > 0) {            
            tmEmprestimo.removeRow(0);
        }
    } 

    DefaultTableModel tmLivro = new DefaultTableModel(null, new String[]{"Id", "Exemplar", "Autor", "Disponibilidade"});
    List<Livro> livros;
    
    private void listaContatosLivro() throws SQLException {
        BdLivro d = new BdLivro();
        livros = d.getLista("%" + jTPesquisar.getText() + "%"); 
        
        mostraPesquisaLivro(livros);
        livros.clear();
    }
    
    private void mostraPesquisaLivro(List<Livro> livros) {
        limpaTabelaLivro();
        
        if (livros.isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Nenhum registro encontrado.");
        } else {            
            String[] linha = new String[] {null, null, null, null};
            for (int i = 0; i < livros.size(); i++) {
                tmLivro.addRow(linha);
                tmLivro.setValueAt(livros.get(i).getId(), i, 0);
                tmLivro.setValueAt(livros.get(i).getExemplar(), i, 1);
                tmLivro.setValueAt(livros.get(i).getAutor(), i, 2);
                tmLivro.setValueAt(livros.get(i).getDisponibilidade(), i, 3);                
            }            
        }
    }
    
    private void limpaTabelaLivro() {       
        while (tmLivro.getRowCount() > 0) {            
            tmLivro.removeRow(0);
        }
    }

    
    private void excluirRegistro() throws SQLException {
        if (jTableEmprestimo.getSelectedRow() != -1) {
            int resp = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir este registro?",
                    "Confirmação!", JOptionPane.YES_NO_OPTION);

            if (resp == JOptionPane.YES_NO_OPTION) {
                int linhaSelecionada = jTableEmprestimo.getSelectedRow();
                int id = (int) jTableEmprestimo.getValueAt(linhaSelecionada, 0);                
                BdEmprestimo d = new BdEmprestimo();
                d.remove(id);

                JOptionPane.showMessageDialog(rootPane, "Registro excluido com sucesso.");
                alteraDisponibilidade("1");
                
                listaContatosEmprestimo();
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Registro não selecionado.");
        }
    }
  
    
    private void alteraDisponibilidade(String status) throws SQLException {
        if ((jTableCliente.getSelectedRow() != -1) || (jTableLivro.getSelectedRow() != -1)) {  
                Livro l = new Livro();
                BdLivro d = new BdLivro();             

                l.setId(Integer.valueOf(pegaIdLivro()));
                l.setDisponibilidade(status);          
                       
                d.alteraDisponibilidadeLivro(l);           
        } else {
            JOptionPane.showMessageDialog(rootPane, "Livro não selecionado.");
        }
    }
    
    private String pegaIdLivro() {
        int linhaSelecionada;
        String s = "0";
        if (jTableEmprestimo.getSelectedRow() != -1) {
            linhaSelecionada = jTableEmprestimo.getSelectedRow();
            s = jTableEmprestimo.getValueAt(linhaSelecionada, 2).toString();
        } else if (jTableLivro.getSelectedRow() != -1) {
            linhaSelecionada = jTableLivro.getSelectedRow();
            s = jTableLivro.getValueAt(linhaSelecionada, 0).toString();
        }

        return s;
    }
    
    private void devolveLivro() throws SQLException, ParseException {
        if (jTableEmprestimo.getSelectedRow() != -1) {
            alteraDisponibilidade("1");          
            int linhaSelecionada = jTableEmprestimo.getSelectedRow();
            int id = (int) jTableEmprestimo.getValueAt(linhaSelecionada, 0);                
            BdEmprestimo d = new BdEmprestimo();
            d.remove(id);         
            
            if (diferencaData() > 0) {
                passaValor(String.valueOf(diferencaData()));
                JOptionPane.showMessageDialog(rootPane, "Emprestimo devolvido após o prazo de vencimento\n"
                        + "gerando uma multa para o cliente."
                        + "\n\nPassou " + diferencaData() + " dias do prazo. Esta multa deve ser registrada...");
                        
                listaContatosEmprestimo();
                listaContatosLivro();    
            } else {
                JOptionPane.showMessageDialog(rootPane, "Emprestimo devolvido com sucesso.");
                listaContatosEmprestimo();
                listaContatosLivro();                
            }           
            
        } else {
            JOptionPane.showMessageDialog(rootPane, "Emprestimo não selecionado.");
        }
    }

    
    private void limpaCamposEmprestimo() {
        jT0IdEmprestimo.setText("");
        jT1IdCliente.setText("");
        jT2IdLivro.setText("");
    }
    
    private void desabilitaCamposEmprestimo() {
        jT0IdEmprestimo.setEditable(false);
        jT1IdCliente.setEditable(false);
        jT2IdLivro.setEditable(false);
        jT3DataEmprestimo.setEditable(false);
        jT4DataDevolucao.setEditable(false);
    }    
    
    private void passaValor(String valor) throws ParseException, SQLException {
        enviaValor = new JFMulta();
        enviaValor.setVisible(true);
        enviaValor.recebe(String.valueOf(diferencaData()), pegaIdCliente());
    }
    
    private String pegaIdCliente() throws SQLException {
        int linhaSelecionada = jTableCliente.getSelectedRow();
                        
        String s = jTableCliente.getValueAt(linhaSelecionada, 0).toString();  
        
        return s;
    }
    

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFEmprestimo().setVisible(true);
            }
        });
    }    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bGPesquisa;
    private javax.swing.JButton jBCadastrar;
    private javax.swing.JButton jBDevolver;
    private javax.swing.JButton jBExcluir;
    private javax.swing.JButton jBNovo;
    private javax.swing.JButton jBPesquisar;
    private javax.swing.JButton jBSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRClientes;
    private javax.swing.JRadioButton jRLivros;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jT0IdEmprestimo;
    private javax.swing.JTextField jT1IdCliente;
    private javax.swing.JTextField jT2IdLivro;
    private javax.swing.JTextField jT3DataEmprestimo;
    private javax.swing.JTextField jT4DataDevolucao;
    private javax.swing.JTextField jTPesquisar;
    private javax.swing.JTable jTableCliente;
    private javax.swing.JTable jTableEmprestimo;
    private javax.swing.JTable jTableLivro;
    // End of variables declaration//GEN-END:variables

}
