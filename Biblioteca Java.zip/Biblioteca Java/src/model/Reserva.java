package model;

import java.util.Date;

public class Reserva {
    private int id;
    private Cliente cliente;
    private Livro livro;
    private Date dataReserva;

    public Reserva(Cliente cliente, Livro livro, Date dataReserva) {
        this.cliente = cliente;
        this.livro = livro;
        this.dataReserva = dataReserva;
    }
    
    public Reserva() {}

    public Reserva(int id, Cliente cliente, Livro livro, Date dataReserva) {
        this.id = id;
        this.cliente = cliente;
        this.livro = livro;
        this.dataReserva = dataReserva;
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Livro getLivro() {
        return livro;
    }

    public Date getDataReserva() {
        return dataReserva;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public void setDataReserva(Date dataReserva) {
        this.dataReserva = dataReserva;
    }
}
