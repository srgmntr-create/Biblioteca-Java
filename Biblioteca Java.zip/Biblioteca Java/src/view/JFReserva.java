package view;

import dao.ClienteDAO;
import dao.LivroDAO;
import dao.ReservaDAO;
import model.Cliente;
import model.Livro;
import model.Reserva;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class JFReserva extends JFrame {

    private JComboBox<Cliente> comboCliente;
    private JComboBox<Livro> comboLivro;
    private JFormattedTextField txtDataReserva;
    private JButton btnSalvar;

    public JFReserva(JFPrincipal telaPrincipal) {
        setTitle("Cadastro de Reserva");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        initComponents();
        carregarCombos();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        comboCliente = new JComboBox<>();
        comboLivro = new JComboBox<>();
        try {
            txtDataReserva = new JFormattedTextField(new javax.swing.text.MaskFormatter("##/##/####"));
        } catch (ParseException e) {
            txtDataReserva = new JFormattedTextField();
        }

        btnSalvar = new JButton("Salvar Reserva");

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Cliente:"), gbc);
        gbc.gridx = 1;
        panel.add(comboCliente, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Livro:"), gbc);
        gbc.gridx = 1;
        panel.add(comboLivro, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Data da Reserva:"), gbc);
        gbc.gridx = 1;
        panel.add(txtDataReserva, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(btnSalvar, gbc);

        add(panel, BorderLayout.CENTER);

        btnSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvarReserva();
            }
        });
    }

    private void carregarCombos() {
        try {
            ClienteDAO clienteDAO = new ClienteDAO();
            List<Cliente> clientes = clienteDAO.listar();
            for (Cliente c : clientes) {
                comboCliente.addItem(c);
            }

            LivroDAO livroDAO = new LivroDAO();
            List<Livro> livros = livroDAO.listar();
            for (Livro l : livros) {
                comboLivro.addItem(l);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar clientes ou livros: " + e.getMessage());
        }
    }

    private void salvarReserva() {
        Cliente cliente = (Cliente) comboCliente.getSelectedItem();
        Livro livro = (Livro) comboLivro.getSelectedItem();
        String dataStr = txtDataReserva.getText();

        try {
            Date dataReserva = new SimpleDateFormat("dd/MM/yyyy").parse(dataStr);

            Reserva reserva = new Reserva(cliente, livro, dataReserva);

            ReservaDAO reservaDAO = new ReservaDAO();
            reservaDAO.adiciona(reserva);

            JOptionPane.showMessageDialog(this, "Reserva salva com sucesso!");
            dispose();
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar reserva: " + ex.getMessage());
        }
    }
}
