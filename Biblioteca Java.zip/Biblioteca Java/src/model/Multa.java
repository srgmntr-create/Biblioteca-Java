package model;

public class Multa {
    private int id_multa;
    private int id_cliente;
    private String descricao;
    private float valor;

    public Multa() {
    }

    public Multa(int id_multa, int id_cliente, String descricao, float valor) {
        this.id_multa = id_multa;
        this.id_cliente = id_cliente;
        this.descricao = descricao;
        this.valor = valor;
    }

    public int getId_multa() {
        return id_multa;
    }

    public void setId_multa(int id_multa) {
        this.id_multa = id_multa;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
}
