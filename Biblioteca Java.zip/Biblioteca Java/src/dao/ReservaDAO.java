package dao;

import java.sql.*;
import java.util.*;
import model.*;
import conexao.Conexao;

public class ReservaDAO {
    private Connection conexao;

    public ReservaDAO() throws SQLException {
        this.conexao = Conexao.getConnection();
    }

    public void adiciona(Reserva r) throws SQLException {
        String sql = "INSERT INTO reserva (id_cliente, id_livro, data_reserva) VALUES (?, ?, ?)";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setInt(1, r.getCliente().getId());
        stmt.setInt(2, r.getLivro().getId());
        stmt.setDate(3, new java.sql.Date(r.getDataReserva().getTime()));
        stmt.execute();
        stmt.close();
    }

    public List<Reserva> listar() throws SQLException {
        String sql = "SELECT * FROM reserva r " +
                     "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                     "JOIN livro l ON r.id_livro = l.id_livro";

        List<Reserva> lista = new ArrayList<>();
        PreparedStatement stmt = conexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Cliente c = new Cliente();
            c.setId(rs.getInt("id_cliente"));
            c.setNome(rs.getString("nome"));

            Livro l = new Livro();
            l.setId(rs.getInt("id_livro"));
            l.setExemplar(rs.getString("exemplar"));
            l.setAutor(rs.getString("autor"));
            l.setEditora(rs.getString("editora"));
            l.setAno((short) rs.getInt("ano"));
            l.setDisponibilidade(rs.getString("disponibilidade"));

            java.sql.Date data = rs.getDate("data_reserva");
            Reserva r = new Reserva(rs.getInt("id_reserva"), c, l, data);
            lista.add(r);
        }

        rs.close();
        stmt.close();
        return lista;
    }
}
