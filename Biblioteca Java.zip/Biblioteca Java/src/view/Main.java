package view;

public class Main {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new JFLogin().setVisible(true); // Mostra a tela de login primeiro
        });
    }
}