# Projeto Biblioteca em Java Desktop

Software para biblioteca em java. O sistema contém somente as funcionalidades básicas, desenvolvido a fim de obter nota para a matéria Engenharia de Software no Curso de Engenharia da Computação.

---

**Author:** Sergio Silva Monteiro

**Data:** 04/2025

# Tecnologias Utilizadas:
- **Netbeans** como IDE
- **Java 7**
- **MySQL** como Banco de Dados